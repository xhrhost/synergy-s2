<?php
header("Location: log.php");
exit();
?>