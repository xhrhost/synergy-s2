<a href="apps/log/index.php">
	<img width=50 height=50 src="apps/log/icon.png" alt="Log"/>
</a>
<br/>
Log
