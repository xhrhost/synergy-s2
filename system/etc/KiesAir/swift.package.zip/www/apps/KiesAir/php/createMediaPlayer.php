<?php
header("Cache-Control: no-cache, must-revalidate, max-age=0");
?>

<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<style type="text/css">
html,body 
{
	background-color: transparent;
	cursor: default;
}
</style>

</head>
<body>
<?php


$QT_Mimetype = array("video/3gpp", "video/mp4", "video/mpeg", "video/quicktime", "video/3gpp2");

$WMP_Mimetype = array("video/x-ms-wmv");

$FLV_Mimetype = array("video/x-flv");

$DIVX_Mimetype = array("video/x-msvideo","video/divx","video/x-matroska");


$platform = $_GET["platform"];
$mimetype = $_GET["mimeType"];
$file = stripslashes($_GET["file"]);
$file = str_replace ("%2B", "+", $file);
$fileName = (strlen($_SERVER["HTTPS"])>0? "https" : "http") . "://".$_SERVER["HTTP_HOST"].str_replace("%2F", "/", rawurlencode ($file));
$height = $_GET["height"];
$width = $_GET["width"];

$EMBED_Tag = '<EMBED SRC="'.$fileName.'" width="'.$width.'" height="'.$height.'" scale="tofit" autostart="true" controller="true"></EMBED>';

$OT_Player = '<OBJECT width="'.$width.'" height="'.$height.'" CLASSID="CLSID:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B" codebase="http://www.apple.com/qtactivex/qtplugin.cab">
					<PARAM name="src" value="'.$fileName.'">
					<PARAM name="autoplay" value="true">
					<PARAM name="controller" value="true">
					<PARAM name="scale" value="tofit">
				
					<embed type="video/quicktime" src="'.$fileName.'" width="'.$width.'" height="'.$height.'" scale="tofit" autostart="true" controller="true" pluginspage="http://www.apple.com/quicktime/download/"></EMBED>	
				</OBJECT>';
				
$WMP_Player = '<OBJECT id="VIDEO" width="'.$width.'" height="'.$height.'" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">
					<PARAM NAME="URL" VALUE="'.$fileName.'">
					<PARAM NAME="AutoStart" VALUE="True">
					<PARAM name="controller" value="true">
					<PARAM name="uiMode" value="full">
					<PARAM name="scale" value="tofit">

					<OBJECT width="'.$width.'" height="'.$height.'" type="application/x-mplayer2" DATA="'.$fileName.'">
						<PARAM NAME="AutoStart" VALUE="True">
						<PARAM name="uiMode" value="full">
						<PARAM name="controller" value="true">
						<PARAM name="scale" value="tofit">
						
							<EMBED SRC="'.$fileName.'" width="'.$width.'" height="'.$height.'" scale="tofit" autostart="true" controller="true" pluginspage="http://www.microsoft.com/Windows/MediaPlayer/"></EMBED>
								
						</OBJECT >
						
				</OBJECT>';

$DIVX_Player = '<object classid="clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616"   
          width="'.$width.'" height="'.$height.'"
          codebase="http://go.divx.com/plugin/DivXBrowserPlugin.cab">   
    <param name="src" value="'.$fileName.'"/>   
        <embed type="video/divx" src="'.$fileName.'"   
           width="'.$width.'" height="'.$height.'"   
           pluginspage="http://go.divx.com/plugin/download/">   
     </embed>   
 </object>';

$FLV_Player = '<object type="application/x-shockwave-flash" data="player_flv_maxi.swf" width="'.$width.'" height="'.$height.'" >' .
        		'<param name="movie" value="player_flv_maxi.swf" />' . 
        		'<param name="allowFullScreen" value="true" />' . 
        		'<param name="wmode" value="opaque" />' . 
        		'<param name="allowScriptAccess" value="sameDomain" />' . 
        		'<param name="quality" value="high" />' . 
        		'<param name="menu" value="true" />' . 	
        		'<param name="FlashVars" value="flv='.$fileName.'&autoplay=1&playercolor=000000&showstop=1&'.
        		'showvolume=1&showtime=1&showplayer=autohide&showloading=autohide&showfullscreen=1&'.
        		'showmouse=autohide&loadingcolor=000000&bgcolor=000000&bgcolor1=000000&bgcolor2=000000&'.
        		'buttoncolor=ffffff&buttonovercolor=c3c4c4&slidercolor1=ffffff&slidercolor2=ffffff&'.
        		'sliderovercolor=ffffff&loadonstop=0&onclick=playpause&onclicktarget=_blank&'.
        		'playertimeout=1500&videobgcolor=000000&volume=80&shortcut=1&playeralpha=100&'.
        		'srturl=video.srt&showiconplay=1&iconplaycolor=ffffff&iconplaybgcolor=000000&'.
        		'iconplaybgalpha=25" />' .
				'<EMBED href="player_flv_maxi.swf" quality=high bgcolor=#FFFFFF width="'.$width.'" height="'.$height.'" NAME="'.$fileName.'" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED>'. 
        	'</object>';

echo "<center>";
				
switch($platform)
{
	case "Windows":
	
		if (in_array($mimetype, $QT_Mimetype)) 
		{
			echo $OT_Player;
		}
		else if (in_array($mimetype, $DIVX_Mimetype)) 
		{
			echo $DIVX_Player;
		}
		else if (in_array($mimetype, $FLV_Mimetype)) 
		{
			echo $FLV_Player;
		}
		else 
		{
			echo $WMP_Player;
		}
		
        break;
		
    case "Mac":
	
		if (in_array($mimetype, $FLV_Mimetype)) 
		{
			echo $FLV_Player;
		}
		else
		{
        	echo $OT_Player;
		}
				
        break;	

	default:
	
		if (in_array($mimetype, $FLV_Mimetype)) 
		{
			echo $FLV_Player;
		}
		else
		{
			echo $EMBED_Tag;
		}
		
		break;
}

echo "</center>";

?>
</body>
</html>
