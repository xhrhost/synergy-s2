<?php
/*
 * argument $contentDispotition must be "attachment" to download or "inline" to reproduce/view
 */
function send_file($path, $mtype, $cacheTime, $contentDispotition) {
	if (!file_exists($path)){
		$status = "{\"status\":\"failure\"}";
		echo ($status);
		exit();
	}
	$stat = stat($path);
	if ($stat === FALSE) throw new Exception ("send_file - ". $path . " not accessible");
	$lastModifiedTimestamp = $stat['mtime'];
	$daterfc822 = date(DATE_RFC822,$lastModifiedTimestamp);
	$daterfc822Expiration = date(DATE_RFC822,time() + $cacheTime);
	
	//Set the Compression Off
	ini_set("zlib.output_compression", "0");
	
	if ($_SERVER["HTTP_IF_MODIFIED_SINCE"]==$daterfc822)
	{
		header("Status: 304");
		header("__Last-Modified: ".$daterfc822);
		exit();
	}
	
	if (strpos($_SERVER['HTTP_USER_AGENT'], "MSIE") !== false) { // if IE
		$filename = rawurlencode(basename($path));
	} else {
		$filename = rawurldecode(basename($path));
	}
	
	header("Status: 200");
	header("Last-Modified: ".$daterfc822);
	header("Expires:".$daterfc822Expiration);
	header("Cache-Control: public, max-age=".$cacheTime);
	header( "X-Sendfile: ".$path);
	if (!$mtype) throw new Exception("mtype must not be null");
	header( "Content-Type: ". $mtype);
	header("Content-Length: ". $stat['size']);
	header( "Content-Disposition: ". $contentDispotition ."; filename=\"". $filename ."\"");
}
?>