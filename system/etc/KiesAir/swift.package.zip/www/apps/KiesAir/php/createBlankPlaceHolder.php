<?php
header("Cache-Control: no-cache, must-revalidate, max-age=0");
?>

<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<style type="text/css">
html,body 
{
	background-color: transparent;
	cursor: default;
}
</style>

</head>
<body>

</body>
</html>
