<?php

// PH
require_once("id3.php");

class FileInfo {
	public $id;
	public $url;
	public $folder;
	public $createTime;
	public $size;
	
	public function __construct($_id, $_url, $_folder, $_createTime, $_size) {
		$this->id = $_id;
		$this->createTime = $_createTime;
		$this->size = $_size;
		$this->url = $_url;
		$this->folder = $_folder;
	}

	public function toString(){
		return "id - " . $this->id . "url - " . $this->url . "creation time - " . $this->createTime . "size - " . $this->size; 
	}
	
    static function ascending($first,$second) {
        if ($first->createTime > $second->createTime) return 1;
        if ($first->createTime < $second->createTime) return -1;
        return 0;
    }	

    static function descending($first,$second) {
        if ($first->createTime > $second->createTime) return -1;
        if ($first->createTime < $second->createTime) return 1;
        return 0;
    }	
    
}

class AudioFileInfo {
	public $id;
	public $url;
	public $folder;
	public $createTime;
	public $size;
	public $artist;
	public $title;
	public $duration;
	
	public function __construct($_id, $_url, $_folder, $_createTime, $_size, $_artist, $_title, $_duration) {
		$this->id = $_id;
		$this->createTime = $_createTime;
		$this->size = $_size;
		$this->url = $_url;
		$this->folder = $_folder;
		$this->artist = $_artist;
		$this->title = $_title;
		$this->duration = $_duration;
	}

	public function toString(){
		
		return "id - " . $this->id . "url - " . $this->url . "creation time - " . $this->createTime . "size - " . $this->size; 
	}
	
    static function ascending($first,$second) {
    	$firstComposition = $first->artist . $first->title;
    	$secondComposition = $second->artist . $second->title;
        if ($firstComposition > $secondComposition) return 1;
        if ($firstComposition < $secondComposition) return -1;
        return 0;
    }	

    static function descending($first,$second) {
    	$firstComposition = $first->artist . $first->title;
    	$secondComposition = $second->artist . $second->title;
    	if ($firstComposition > $secondComposition) return -1;
        if ($firstComposition < $secondComposition) return 1;
        return 0;
    }	
    
}

class PictureFileInfo{
	public $id;
	public $url;
	public $folder;
	public $createTime;
	public $size;
	public $width;
	public $height;
	
	public function __construct($_id, $_url, $_folder, $_createTime, $_size, $_width, $_height) {
		$this->id = $_id;
		$this->createTime = $_createTime;
		$this->size = $_size;
		$this->url = $_url;
		$this->folder = $_folder;
		$this->height = $_height;
		$this->width = $_width;
	}

	public function toString(){
		return "id - " . $this->id . "url - " . $this->url . "creation time - " . $this->createTime . "size - " . $this->size; 
	}
	
    static function ascending($first,$second) {
        if ($first->createTime > $second->createTime) return 1;
        if ($first->createTime < $second->createTime) return -1;
        return 0;
    }	

    static function descending($first,$second) {
        if ($first->createTime > $second->createTime) return -1;
        if ($first->createTime < $second->createTime) return 1;
        return 0;
    }	
}

class Response {
	public $items;
	public $size;
	
	public function __construct($_items, $_size) {
		$this->items= $_items;
		$this->size = $_size;
	}

	public function toString(){
		
		return "$items - " . $this->$items . "size - " . $this->size; 
	}
}

function formatTime($hours, $minutes, $seconds) {
	if ($seconds < 10) {
		$seconds = "0" . $seconds;
	}
	if ($hours > 0 && $minutes < 10) {
		$minutes = "0" . $minutes;
	}
	
	$time = ($hours > 0) ? $hours . ":" : "";
	$time .= $minutes . ":" . $seconds;
	return $time;
}

function add_file($id, $filePath){
	
	global $lastUpdated;
	global $eTag;
	
	$stat = stat($filePath);
	$creationTime = $stat['mtime'];
	$fileSize = $stat['size'];
	$folder = getFileFolder($creationTime);
	if ($stat === FALSE){
		 throw new Exception ("get_dir_files - ". $filePath . " not accessible");
	}
	
	if ($creationTime > $lastUpdated) {
		$lastUpdated = $creationTime;
	}
	
	// Check is it AUDIO file
	if (stripos($filePath, AUDIOS_PATH) !== false) {
		$artist = "";
		$title = "";
		$duration = "";
		
		$eTag .= $filePath;
		
		// For mp3 files try to get additional info from ID3 tag
		if (strtolower(pathinfo($filePath, PATHINFO_EXTENSION)) == "mp3") {
			$mp3File = new ID3($filePath, FALSE);
			$artist = $mp3File->getArtist();
			$title = $mp3File->getTitle();
			$duration = $mp3File->getDuration();
			
			if ($duration > 0) {
				//format duration
				$seconds = floor($duration-(floor($duration/60)*60));
				$minutes = floor($duration/60);
				$hours = 0;
				if ($minutes >= 60) {
					$hours = floor($minutes/60);
					$minutes = floor($minutes-(floor($minutes/60)*60));
				}
				$duration = formatTime($hours, $minutes, $seconds);
			} else {
				$duration = null;
			}
		}
		$fileInfo = new AudioFileInfo($id, $filePath, $folder, $creationTime, $fileSize, $artist, $title, $duration);
	}
	else if (stripos($filePath, PICTURES_PATH) !== false){
		
		// get picture size 
		list($width, $height, $type, $attr) = getimagesize($filePath);
		$fileInfo = new PictureFileInfo($id, $filePath, $folder, $creationTime, $fileSize, $width, $height);
	}
	else {
		//Process regular file
		echo $filePath;
		$fileInfo = new FileInfo($id, $filePath, $folder, $creationTime, $fileSize);
	}

	return $fileInfo;

}


// TODO:
// 1. Use stat instead of is_file so you can get exists+file/dir+last modified time in one IO
// 2. Have a pre-scan mode, than returns only the maximum last modified time of tree for HTTP caching. In pre-scan mode
//      use only directories.
// 3.  the caching algorithm:
//     a) run pre-scan and retreive maximum last modified time into variable S
//     b) obtain HTTP header If-None-Match int variable C
//     c) if C==S then return HTTP status 304 and exit
//     d) otherwise set header Etag=W"<S>"
//     e) continue to scan content normally
function dir_walk($callback, $serchStr, $dir, $types) {
    global $id;
	$files = array();
	
	if ($dh = opendir($dir)) {

		while (($file = readdir($dh)) !== false) {
            if ($file === '.' || $file === '..') {
                continue;
            }
            if (is_file($dir . $file)) {

            	if (is_array($types)) {
                    if (!in_array(strtolower(pathinfo($dir . $file, PATHINFO_EXTENSION)), $types, true)) {
                        continue;
                    }
                }
                
                $addFile = true;
                if ($serchStr) {
                	if (stripos($file, $serchStr) === false) {
                		$addFile = false;
                	}
                }
                
                if ($addFile) {
                	$fileInfo = $callback($id, $dir . $file);
                	if ($fileInfo->size > 0){ 
                		$files[] = $fileInfo; 
                		$id++;
                	}
                }
                
            }else{
            	$subfiles = dir_walk($callback, $serchStr, $dir . $file . DIRECTORY_SEPARATOR, $types);
            	if (count($subfiles) > 0) {
	            	foreach($subfiles as $subfile) {
	            		$files[] = $subfile;
	            	} 
            	}
            }
        }
        closedir($dh);
    }
    
    return $files;
}

function get_dir_files($dir_path, $startIndex, $maxItems, $sortOrder, $serchStr, $types, $cacheTime) {
	$files = dir_walk('add_file', $serchStr, $dir_path, $types);
	$files_json = null;
	
	if (is_array($files)){
		
		$total = count($files);
		
		if ($sortOrder && ($sortOrder=="ascending" || $sortOrder=="descending")) {
			$fileInfoClass = ($dir_path == AUDIOS_PATH) ? "AudioFileInfo" : "FileInfo";
			usort($files,array($fileInfoClass,$sortOrder));
		}
		
		// Get part of files
		$files = array_slice($files, $startIndex, $maxItems);
		
		$response = new Response($files, $total);
		
		$response_json = json_encode($response); 
	}
	
	return $response_json;
}

function getFileFolder($dateTime) {
	global $dateSorting;

   	$curDay = date("d");
   	$curMonth = date("m");
   	$curYear = date("Y");
   	$weekDay = date("w");
   	
   	$today  = mktime(0, 0, 0, $curMonth, $curDay, $curYear);
	$yesterday = mktime(0, 0, 0, $curMonth, $curDay-1, $curYear);
   	$thisWeek = mktime(0, 0, 0, $curMonth, $curDay-$weekDay, $curYear);
   	$lastWeek = mktime(0, 0, 0, $curMonth, $curDay-7-$weekDay, $curYear);
	$thisMonth = mktime(0, 0, 0, $curMonth, 1, $curYear);
   	$lastMonth = mktime(0, 0, 0, $curMonth-1, 1, $curYear);
   	$thisYear = mktime(0, 0, 0, 1, 1, $curYear);
   	$lastYear = mktime(0, 0, 0, 1, 1, $curYear-1);
  	
	$folder = $dateSorting["older"];

	if ($dateTime >= $today) {
		$folder = $dateSorting["today"];
	} else if ($dateTime >= $yesterday) {
		$folder = $dateSorting["yesterday"];
	} else if ($dateTime >= $thisWeek) {
		$folder = $dateSorting["thisWeek"];
	} else if ($dateTime >= $lastWeek) {
		$folder = $dateSorting["lastWeek"];
	} else if ($dateTime >= $thisMonth) {
		$folder = $dateSorting["thisMonth"];
	} else if ($dateTime >= $lastMonth) {
		$folder = $dateSorting["lastMonth"];
	} else if ($dateTime >= $thisYear) {
		$folder = $dateSorting["thisYear"];
	} else if ($dateTime >= $lastYear) {
		$folder = $dateSorting["lastYear"];
	}
	
	return $folder;
};

// Disable caching of the current document:
function setHeaders($isETag, $isError, $eTag, $lastUpdated) {
	if($isError) {
		header('Status: 404 Not Found');
	} else if ($isETag) {
		$eTag = md5($eTag . $lastUpdated);
		header('ETag: W/"' . $eTag . '"');
		header('Cache-Control: private, must-revalidate, max-age=0');
	} else {
		header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
		header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header('Pragma: no-cache');
	}
}

function sanitizeString($inStr) {
	$outStr = "";
	for ($i=0; $i<strlen($inStr); $i++) {
		if ($inStr[$i] == "\\") {
			$i++;
		}
		$outStr .= $inStr[$i];
	}
	return $outStr;
}

$photos_directory = "";
$audio_directory = "";

//dynamic location of photos directory
if (!getenv("WEBPHONE_AUDIO_PATH"))
{
    $audio_directory = "/sdcard/audio/";
}
else
{
    $audio_directory = getenv("WEBPHONE_AUDIO_PATH");
}

//dynamic location of photos directory
if (!getenv("WEBPHONE_CAMERA_PATH"))
{
    $photos_directory = "/sdcard/DCIM/Camera/";
}
else
{
    $photos_directory = getenv("WEBPHONE_CAMERA_PATH");
}

define("PICTURES_PATH", $photos_directory);
define("VIDEOS_PATH", $photos_directory);
define("AUDIOS_PATH", $audio_directory);

define("PICTURE_TYPES", "jpg,gif,jpeg,png");
define("VIDEO_TYPES", "3gp,avi,flv,mp4");
define("AUDIO_TYPES", "mp3,wav");
define("CACHE_TIME", 0);

$dateSorting = array("today"=>"today", "yesterday"=>"yesterday",
					 "thisWeek"=>"thisWeek", "lastWeek"=>"lastWeek",
					 "thisMonth"=>"thisMonth", "lastMonth"=>"lastMonth",
					 "thisYear"=>"thisYear", "lastYear"=>"lastYear", "older"=>"older");

$type = $_GET["type"];
$startIndex = $_GET["startIndex"];
$maxItems = $_GET["maxItems"];
$sortOrder = $_GET["sortOrder"];
$serchStr = $_GET["searchQuery"];
$deleteFile = $_GET["deleteFile"];
$getInfo = $_GET["getInfo"];

$folder = "";
$media_types = "";
$id=0;
$eTag = "";
$lastUpdated = 0;
$isError = false;

if ($deleteFile) {
	$deleteFile = sanitizeString($deleteFile);
	if (is_file($deleteFile)) {
		$isSuccess = unlink($deleteFile);
		$isError = !$isSuccess;
		$response = $isError ? "FAILED Cant't delete file " . $deleteFile : "SUCCESS";
	} else {
		$isError = true;
		$response = "FAILED Cant't find file " . $deleteFile;
	}
} else if ($getInfo) {
	$getInfo = sanitizeString($getInfo);
	if (is_file($getInfo)) {
		$folder = AUDIOS_PATH;
		$files[]= add_file(0, $getInfo);
		$total = count($files);
		$objResponse = new Response($files, $total);
		$response = json_encode($objResponse); 
	} else {
		$isError = true;
		$response = "File " . $getInfo . " not found";
	}
} else {
	if ($type == 'photo') {
		$folder = PICTURES_PATH;
		$media_types = explode(",", PICTURE_TYPES);
	} else if ($type == 'video') {
		$folder = VIDEOS_PATH;
		$media_types = explode(",", VIDEO_TYPES);
	} else if ($type == 'audio') {
		$folder = AUDIOS_PATH;
		$media_types = explode(",", AUDIO_TYPES);
	} else {
		$isError = true;
		$response = "Unsuported type";
	}

	if (!$isError) {
		$serchStr = sanitizeString($serchStr);		
		$response = get_dir_files($folder, $startIndex, $maxItems, $sortOrder, $serchStr, $media_types, CACHE_TIME);
	} 
}

$useETag = ($folder == AUDIOS_PATH) ? true : false; 
setHeaders($useETag, $isError, $eTag, $lastUpdated);

echo ($response);
?>