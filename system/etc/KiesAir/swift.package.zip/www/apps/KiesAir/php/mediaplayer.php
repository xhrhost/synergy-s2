<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<script src="mediaplayer.js" type="text/javascript"></script>
<script src="browserDetect.js" type="text/javascript"></script>

<script type="text/javascript">

var mimeTypeList = new Array("video/x-ms-wmv", "udio/x-ms-wma", "video/3gpp", "video/mp4", "audio/mpeg", "video/mpeg");

var fileTypeList = new Array(".wmv", ".wma", ".3gp", ".mp4", ".mpg");

var mp = new MPManager.MediaPlayer(); 

</script>
</head>
<body>

<iframe frameborder="0" width="100%" height="100%" id="playerCode" name="palyerCode" src="" scrolling="no"></iframe>

<script type="text/javascript">

mp.setBrowser(BrowserDetect.browser);
mp.setPlatform(BrowserDetect.OS);
mp.setVersion(BrowserDetect.version);

mp.setHeight(600);
mp.setWidth(800);

if(mp)
{	
	var mimeType = "unknown";
	
	var file = decodeURI(window.location.search.substr(1));
	
	var ext = file.substr(file.lastIndexOf('.'));
	
	for(var i = 0; i < fileTypeList.length; i++) 
	{
		if(ext.toLowerCase() == fileTypeList[i]) 
		{ 
			mimeType = mimeTypeList[i];
		}
	}
	
	if( mimeType != 0 && file!="")
	{
		mp.setMimeType(mimeType);

		mp.play("playerCode", file);
	}
}
	
</script>

</body>
</html>
