<?php
// Disable caching of the current document:
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header('Pragma: no-cache');

$target_path = $_GET['file'];

//$output = shell_exec('am broadcast -a android.intent.action.MEDIA_MOUNTED -d file:///sdcard');
$output = shell_exec ("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file:". str_replace('%2F', '/', rawurlencode($target_path)));
//$output = shell_exec ("am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://". str_replace('%2F', '/', rawurlencode($target_path)));
$status = "{\"status\":\"success\"}";
echo ($status);
//echo ($output);
?>