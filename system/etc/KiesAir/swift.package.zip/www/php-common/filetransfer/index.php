﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Filetransfer Test</title>
		<script type="text/javascript" src="TransferManager.js"></script>

		<script type="text/javascript">
			var _fireBugEnabled = false;
			var xferMgrInst = null;
			/*
			 * use function mytest_progressDataErrorHandler as the context object
			 * when adding uploads/downloads
			 */
			var myContext = new String("photos");

			function _fireBugLog(s)
			{
				if(_fireBugEnabled)
					console.log(s);
			}

			function pageInit()
			{
				try
				{
					console.log("Test firebug availability");
					_fireBugEnabled = true;
				}
				catch(ex)
				{
				}

				try
				{
					if(xferMgrInst == null)
					{
						xferMgrInst = new TransferManagerInstance("TransferManagerApplet");
						xferMgrInst.setNotficationCallback(mytest_notficationCallbackCB);
					}
				}
				catch(e)
				{
					alert("getCallbackObject(): " + e);
				}
			};

			function getFileTransferCallbackObject()
			{
				return xferMgrInst;
			}
			
			function mytest_selectFilesCB(selectedFiles)
			{
				if(selectedFiles == null)
					return;

				var devDest = document.getElementById("devDest").value;
				var serverurl = location.href.substring(0, location.href.lastIndexOf(location.pathname));
				for(var i=0; i<selectedFiles.length; i++)
				{
					var j = selectedFiles[i].fileName.lastIndexOf("/");
					if (j==-1)
					{
						j = selectedFiles[i].fileName.lastIndexOf("\\");
					}

					var s = "";
					if(j != -1)
						s = selectedFiles[i].fileName.substring(j+1);
					else
						s = selectedFiles[i].fileName;					
					if(!xferMgrInst.addUpload(selectedFiles[i].fileName,
						serverurl + devDest + s,
						selectedFiles[i].fileSize,
						true,
						myContext))
						
					{
						alert(selectedFiles[i].fileName + "   Not added to upload queue");
					};
				}

				xferMgrInst.startUpload();
			}

			function mytest_selectFolderCB(folder)
			{
				if(folder == null)
					return;

				var devDest = document.getElementById("devDest").value;
				var serverurl = location.href.substring(0, location.href.lastIndexOf(location.pathname));
				var test = [
{n:"Picture 357.jpg"	   , s:3188863}
,{n:"Picture 355.jpg"	   , s:2861883}
,{n:"Picture 354.jpg"	   , s:3956488}
,{n:"Picture 353.jpg"	   , s:3484333}
];
				for(i=0; i<test.length; i++)
				{
					if(!xferMgrInst.addDownload(serverurl + devDest + test[i].n,
						folder + test[i].n,
						test[i].s,
						document.getElementById("cbTop").checked,
						myContext))
					{
						alert(serverurl + devDest + test[i].n + "   Not added to download queue");
					};
				}
				
				xferMgrInst.startDownload();
			}

			function mytest_notficationCallbackCB(progressData)
			{

				if(progressData.msgType > 0)
				{
					_fireBugLog("msgSrc=" + progressData.msgSrc + " msgType=" + progressData.msgType +
						" errorCode=" + progressData.errorCode +
						" context=" + progressData.context +
						" source=" + progressData.source +
						" destination=" + progressData.destination);
				}

				var elem;
				if(progressData.msgSrc==0)
				{
					if(progressData.msgType<3)
					{
						elem = document.getElementById("fileUploadProgress");
						elem.title = progressData.source;
						elem.alt = progressData.source + " # " + progressData.fP + "%";
						elem.children[0].style.width = progressData.fP + "%";

						elem = document.getElementById("totalUploadProgress");
						elem.title = elem.alt = progressData.tP + "%";
						elem.children[0].style.width = progressData.tP + "%";

						document.getElementById("fileUploadText").innerHTML =
							"(" + progressData.cT + "/" + progressData.rT + ") " +
							((progressData.msgType == 2)? "All Completed;":
							((progressData.msgType == 1)? "Completed: " : "Transferring: " ) + progressData.source);
					}

					if(progressData.msgType == 3)
					{
						mytest_progressDataErrorHandler(progressData);
					}
				}
				else if (progressData.msgSrc==1)
				{
					if(progressData.msgType<3)
					{
						elem = document.getElementById("fileDownloadProgress");
						elem.title = progressData.destination;
						elem.alt = progressData.destination + " # " + progressData.fP + "%";
						elem.children[0].style.width = progressData.fP + "%";

						elem = document.getElementById("totalDownloadProgress");
						elem.title = elem.alt = progressData.tP + "%";
						elem.children[0].style.width = progressData.tP + "%";

						document.getElementById("fileDownloadText").innerHTML =
							"(" + progressData.cT + "/" + progressData.rT + ") " +
							((progressData.msgType == 2)? "All Completed":
							((progressData.msgType == 1)? "Completed: " : "Transferring: ") + progressData.source);
					}

					if(progressData.msgType == 3)
					{
						mytest_progressDataErrorHandler(progressData);
					}
				}
			}

			function mytest_progressDataErrorHandler(progressData)
			{
				if(progressData.errorCode == 3)
				{
					// Destination exists
					var overwrite = confirm("Destination File exists Overwrite?");
					if(progressData.msgSrc==0)
					{
						if(overwrite)
							xferMgrInst.resumeUpload(progressData.source, progressData.destination, true);
						else
							xferMgrInst.removeUpload(progressData.source, progressData.destination);
					}
					else if (progressData.msgSrc==1)
					{
						if(overwrite)
							xferMgrInst.resumeDownload(progressData.source, progressData.destination, true);
						else
							xferMgrInst.removeDownload(progressData.source, progressData.destination)
					}
					return;
				}
				else if (progressData.errorCode == 1)
				{
					// Disk_space
					alert("Disk_space");
				}
				else if (progressData.errorCode == 2)
				{
					// Network
					alert("Network");
				}
				else if (progressData.errorCode == 4)
				{
					alert("Destination subpath (sib-directory) not exist");
					// Destination subpath (sib-directory) not exist
				}
				else if (progressData.errorCode == 5)
				{
					// UNAUTHORIZED
					alert("UNAUTHORIZED");
				}
				else
				{
					alert("Other progressData.errorCode=" + progressData.errorCode);
				}

				if(progressData != null)
				{
					document.getElementById("tbSource").value = progressData.source;
					document.getElementById("tbDestination").value = progressData.destination;
					setStatusMessage("progressData.errorCode = "+ progressData.errorCode);
				}
			}

			function setStatusMessage(msg)
			{
				document.getElementById("statusMessage").innerHTML = msg;
			}

			function uClickResumeDownload()
			{
				setStatusMessage("");
				var s = document.getElementById("tbSource").value;
				var d = document.getElementById("tbDestination").value;
				if((s.length !=0 ) && (d.length != 0))
				{
					xferMgrInst.resumeDownload(s, d, document.getElementById("cbOvewrite").checked);
				}
			}

			function uClickRemoveDownload()
			{
				setStatusMessage("");
				var s = document.getElementById("tbSource").value;
				var d = document.getElementById("tbDestination").value;
				if((s.length !=0 ) && (d.length != 0))
					xferMgrInst.removeDownload(s, d);
			}

			function uClickResumeUpload()
			{
				setStatusMessage("");
				var s = document.getElementById("tbSource").value;
				var d = document.getElementById("tbDestination").value;
				if((s.length !=0 ) && (d.length != 0))
				{
					xferMgrInst.resumeUpload(s, d, document.getElementById("cbOvewrite").checked);
				}
			}

			function uClickRemoveUpload()
			{
				setStatusMessage("");
				var s = document.getElementById("tbSource").value;
				var d = document.getElementById("tbDestination").value;
				if((s.length !=0 ) && (d.length != 0))
					xferMgrInst.removeUpload(s, d);
			}

			function uClickAddUpload()
			{
				/*
				 * Examples for 2nd param is you want to restrict filetype (null == all files)
				 * ["Image files","png","jpg","jpeg","gif","tif","tiff"]
				 * ["Music files","mp3","wma"]
				 * ["Video files","divx","mpeg","mpg","flv","mp4"]
				 */
				var filter = null;
				if(!xferMgrInst.selectFiles("Images to Upload", filter, "Upload", mytest_selectFilesCB))
				{
					alert("Dialog already up");
				}
			}

			function uClickAddDownload()
			{
				if(!xferMgrInst.selectFolder("Select Download Location", "All Folders", "Download", null, mytest_selectFolderCB))
				{
					alert("Dialog already up");
				}
			}
		</script>
	</head>

	<body onload='pageInit();'>
		<table>
			<tr >
				<td align="center" colspan="6"><h2>Transfer Manager Applet Test</h2></td>
			</tr>

			<tr>
				<td align="right">Source:</td>
				<td colspan="5">
					<input id="tbSource" style="width:100%" type="text" name="tbSource" />
				</td>
			</tr>
			<tr>
				<td align="right">Destination:</td>
				<td colspan="5"><input id="tbDestination" style="width:100%" type="text" name="tbDestination" /></td>
			</tr>
			<tr>
				<td colspan="5"><br /></td>
			</tr>

			<tr>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td colspan='2'>
					Device Dest : <input id="devDest" type="text" name="devDest" value="/sdcard/DCIM/Camera/" />
				</td>
				<td colspan='3'>
					<input id="cbOvewrite" type="checkbox" name="cbOvewrite" /> Overwrite on Resume
					<input id="cbTop" type="checkbox" name="cbTop" /> Add at Top
				</td>
			</tr>

			<tr>
				<td colspan="6"><br /></td>
			</tr>

			<tr>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td align="center" colspan="2" style='border-bottom:thin solid'><b>Download</b></td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td align="center" colspan="2" style='border-bottom:thin solid'><b>Upload</b></td>
			</tr>
			<tr>
				<td colspan="5"><br /></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td align="center" colspan="2">
					<input style="width:100px" type='button' id="addDownloadBtn" name='addDownloadBtn' value='Add' onclick='uClickAddDownload();'/>
					<input style="width:100px;" type='button' name='removeDlBtn' value='Remove' onclick='uClickRemoveDownload();'/>
					<input style="width:100px" type='button' name='resumeDlBtn' value='Resume' onclick='uClickResumeDownload();'/>
				</td>
				<td>&nbsp;</td>
				<td align="center" colspan="2">
					<input style="width:100px" type='button' id="addUploadBtn" name='addUploadBtn' value='Add' onclick='uClickAddUpload();' />
					<input style="width:100px" type='button' name='removeUlBtn' value='Remove' onclick='uClickRemoveUpload();' />
					<input style="width:100px" type='button' name='resumeUlBtn' value='Resume' onclick='uClickResumeUpload();' />
				</td>
			</tr>

			<tr>
				<td>&nbsp;</td>
				<td colspan="5"><hr /></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td colspan="5">
					<div style='width:100%;'>
						<p>Download stats:</p>
						<div id='fileDownloadProgress' style='height:20px;width:100%;border:thin solid'  title='' >
							<img src='images/blue.png' alt='fileDownloadProgress' style='width:0%;height:100%' />
						</div>
						<div id='fileDownloadText' style='font-size:x-small'>&nbsp;</div>
						<br />
						<div id='totalDownloadProgress' style='height:20px;width:100%;border:thin solid'  title='' >
							<img src='images/blue.png' alt='totalDownloadProgress' style='width:0%;height:100%' />
						</div>
					</div>
					<br />
					<div style='width:100%;'>
						<p>Upload stats:</p>
						<div id='fileUploadProgress' style='height:20px;width:100%;border:thin solid'  title='' >
							<img src='images/blue.png' alt='fileUploadProgress' style='width:0%;height:100%' />
						</div>
						<div id='fileUploadText' style='font-size:x-small'>&nbsp;</div>
						<br />
						<div id='totalUploadProgress' style='height:20px;width:100%;border:thin solid'  title='' >
							<img src='images/blue.png' alt='totalUploadProgress' style='width:0%;height:100%' />
						</div>
					</div>
					<br />
					<hr />
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td id="statusMessage" colspan="5" style="background:silver;"></td>
			</tr>
		</table>

<!--
For logging either use the param in applet

			<param name="org.apache.commons.logging.simplelog.log.com.samsung.swift.filetransfer" value="info">
			<param name="org.apache.commons.logging.simplelog.log.org.apache.http" value="debug">
			<param name="org.apache.commons.logging.simplelog.log.org.apache.http.wire" value="error">

OR set a java system property
			-Dorg.apache.commons.logging.simplelog.log.com.samsung.swift.filetransfer=debug
			-Dorg.apache.commons.logging.simplelog.log.org.apache.http=debug
			-Dorg.apache.commons.logging.simplelog.log.org.apache.http.wire=error
-->
		<applet
			id='TransferManagerApplet'
			name='TransferManagerApplet'
			code='com.samsung.swift.filetransfer.gui.TransferManagerApplet'
			archive='TransferManager.jar,commons-codec-1.4.jar,commons-logging-api-1.1.1.jar,httpcore-4.0.1.jar,httpclient-4.0.1.jar'
			width='3'
			height='3'
			MAYSCRIPT></applet>
	</body>
</html>
